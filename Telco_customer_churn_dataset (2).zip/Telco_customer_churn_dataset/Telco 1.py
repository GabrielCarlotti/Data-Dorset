#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix

data= pd.read_csv("Data propre telco csv.csv",sep=";") 
data.head()


# In[2]:


# Change the NaN values by the median
median_total_charges = data['Total Charges'].median()
data['Total Charges'].fillna(median_total_charges, inplace=True)


# In[3]:


# Definition of the target variable
X = data.drop('Churn Value', axis=1)
y = data['Churn Value']


# In[4]:


y.head()


# In[5]:


X.head()


# In[6]:


# Split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
X_train.dropna()
X_test.dropna()
y_train.dropna()
y_test.dropna()


# In[7]:


# Definition and training

rf_model = RandomForestClassifier(random_state=42)
rf_model.fit(X_train, y_train)


# In[8]:


# Prediction

y_pred = rf_model.predict(X_test)


# In[9]:


# Evaluation

accuracy = accuracy_score(y_test, y_pred)
report = classification_report(y_test, y_pred)
conf_matrix = confusion_matrix(y_test, y_pred)


# In[10]:


# Print the evaluation

print("Accuracy:", accuracy)
print("Classification Report:\n", report)
print("Confusion Matrix:\n", conf_matrix)


# In[11]:


import matplotlib.pyplot as plt
from sklearn.metrics import plot_confusion_matrix

# Confusion Matrix

plt.figure(figsize=(8, 8))
plot_confusion_matrix(rf_model, X_test, y_test, 
                      display_labels=['Non Churn', 'Churn'],
                      cmap='Blues', 
                      normalize=None)
plt.title('Confusion matrix for our model')
plt.show()


# In[12]:


def predict_churn(client_id):
    # Check
    
    new_data=pd.read_csv("Data propre telco avec les id.csv",sep=';')
    if client_id not in new_data['CustomerID'].values:
        return "ID client not found."

    client_data = new_data[new_data['CustomerID'] == client_id]

    # Check
    if client_data['Churn Value'].iloc[0] == 1:
        return "The client already canceled his plan."

    # Settings
    X_client = client_data.drop(['CustomerID','Churn Value'], axis=1)

    # Prediction
    churn_probability = rf_model.predict_proba(X_client)[0][1]
    return f"Churn probability : {churn_probability:.2f}"

predict_churn("1393-IMKZG")


# In[13]:


#export models

path1 = 'C:/Users/Gabriel/Desktop/Titanic notebook/model_telco.pkl'

import pickle

with open(path1, 'wb') as fichier1:
    pickle.dump(rf_model, fichier1)


# In[ ]:




