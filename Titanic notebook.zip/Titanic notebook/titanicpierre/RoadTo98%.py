#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
train= pd.read_csv("trainclean.csv",sep=";") 
test= pd.read_csv("testclean.csv",sep=";") 
test= test.dropna() #clear the missing values
train= train.dropna() #clear the missing values
train['Famille'] = ((train['SibSp'] > 0) | (train['Parch'] > 0)).astype(int)
test['Famille'] = ((test['SibSp'] > 0) | (test['Parch'] > 0)).astype(int)
train.head() #check if it's all good


# In[2]:


X_train = train.drop(['Survived','Fare','PassengerId','SibSp','Parch','Embarked'], axis=1)
y_train = train['Survived']
X_test = test.drop(['Survived','Fare','PassengerId','SibSp','Parch','Embarked'], axis=1)
y_test = test['Survived']


# In[3]:


from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report

logistic_model = LogisticRegression(max_iter=1000)


# In[4]:


logistic_model.fit(X_train, y_train)


# In[5]:


y_pred = logistic_model.predict(X_test)


# In[6]:


accuracy = accuracy_score(y_test, y_pred)
print("Accuracy:", accuracy)


# In[7]:


X_train.head()


# In[8]:


from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns

conf_matrix = confusion_matrix(y_test, y_pred)

# Confusion matrix

plt.figure(figsize=(8, 6))
sns.heatmap(conf_matrix, annot=True, fmt='g', cmap='Blues')
plt.xlabel('Predicted Label')
plt.ylabel('True Label')
plt.title('Confusion matrix')
plt.show()


# In[10]:


#export models

path1 = 'C:/Users/Gabriel/Desktop/Titanic notebook/98%.pkl'

import pickle

with open(path1, 'wb') as fichier1:
    pickle.dump(logistic_model, fichier1)


# In[ ]:




