#!/usr/bin/env python
# coding: utf-8

# In[1]:


#import

import pandas as pd
data= pd.read_csv("DATA clean CSV avec age.csv",sep=";") 
data= data.dropna() #clear the missing values
data.head() #check if it's all good


# In[2]:


data=data.drop(["PassengerId","IsAgeAvailable"],axis=1) #clear the non-necessary columns


# In[3]:


print(data) #check if it worked


# In[4]:


# Converting text Boolean columns to numeric values

data['Embarked_S'] = data['Embarked_S'].map({'VRAI': 1, 'FAUX': 0})
data['Embarked_C'] = data['Embarked_C'].map({'VRAI': 1, 'FAUX': 0})
data['Embarked_Q'] = data['Embarked_Q'].map({'VRAI': 1, 'FAUX': 0})
data.head()


# In[5]:


from sklearn.model_selection import train_test_split

# Separation of features and target variable

X = data.drop('Survived', axis=1)
y = data['Survived']

# Splitting data into training and testing sets

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.20, random_state=42)


# In[6]:


from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report

# Building the logistic regression model

logistic_model = LogisticRegression(max_iter=1000) #raising the max iteration to be able to run the entire model


# In[7]:


# Training

logistic_model.fit(X_train, y_train)


# In[8]:


# Prediction 

y_pred = logistic_model.predict(X_test)


# In[9]:


# First accuracy test

accuracy = accuracy_score(y_test, y_pred)
print("Accuracy:", accuracy)


# In[10]:


# Hyperparameters optimisation

from sklearn.model_selection import GridSearchCV

# Definition of the grid
param_grid = {
    'C': [0.01, 0.1, 1, 10, 100],
    'solver': ['lbfgs', 'newton-cg', 'liblinear', 'sag', 'saga']
}

# Creation of grid search with cross validation

grid_search = GridSearchCV(logistic_model, param_grid, cv=5, scoring='accuracy')

# Training of the grid search

grid_search.fit(X_train, y_train)

# Printing the best parameters

print("Meilleurs paramètres:", grid_search.best_params_)
print("Meilleur score:", grid_search.best_score_)


# In[11]:


# Reconstruction and training of the model with the best parameters

final_model = LogisticRegression(C=10, solver='liblinear',max_iter=1000)
final_model.fit(X_train, y_train)

# Reevaluation

final_y_pred = final_model.predict(X_test)
final_accuracy = accuracy_score(y_test, final_y_pred)
final_report = classification_report(y_test, final_y_pred)

print("Accuracy finale:", final_accuracy)
print("Rapport de classification final:")
print(final_report)


# In[12]:


# Second model without the ages

datasansage= pd.read_csv("DATA clean CSV sans age.csv",sep=";")
datasansage= datasansage.drop(["PassengerId","IsAgeAvailable","Age"],axis=1)
datasansage= datasansage.dropna()
datasansage.head()


# In[13]:


datasansage['Embarked_S'] = datasansage['Embarked_S'].map({'VRAI': 1, 'FAUX': 0})
datasansage['Embarked_C'] = datasansage['Embarked_C'].map({'VRAI': 1, 'FAUX': 0})
datasansage['Embarked_Q'] = datasansage['Embarked_Q'].map({'VRAI': 1, 'FAUX': 0})
datasansage.head()


# In[14]:


from sklearn.model_selection import train_test_split

X2 = datasansage.drop('Survived', axis=1)
y2 = datasansage['Survived']

X_train2, X_test2, y_train2, y_test2 = train_test_split(X2, y2, test_size=0.20, random_state=42)


# In[15]:


from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report

logistic_modelsansage = LogisticRegression(max_iter=1000)


# In[16]:


logistic_modelsansage.fit(X_train2, y_train2)


# In[17]:


y_pred2 = logistic_modelsansage.predict(X_test2)


# In[18]:


accuracysansage = accuracy_score(y_test2, y_pred2)
print("Accuracy:", accuracysansage)


# In[19]:


from sklearn.model_selection import GridSearchCV

param_grid2 = {
    'C': [0.01, 0.1, 1, 10, 100],
    'solver': ['lbfgs', 'newton-cg', 'liblinear', 'sag', 'saga']
}

grid_search2 = GridSearchCV(logistic_modelsansage, param_grid2, cv=5, scoring='accuracy')

grid_search2.fit(X_train2, y_train2)

print("Meilleurs paramètres:", grid_search2.best_params_)
print("Meilleur score:", grid_search2.best_score_)


# In[20]:


final_model2 = LogisticRegression(C=1, solver='lbfgs',max_iter=1000)
final_model2.fit(X_train2, y_train2)

final_y_pred2 = final_model2.predict(X_test2)
final_accuracy2 = accuracy_score(y_test2, final_y_pred2)
final_report2 = classification_report(y_test2, final_y_pred2)

print("Accuracy finale:", final_accuracy2)
print("Rapport de classification final:")
print(final_report2)


# In[21]:


#We notice that we obtain similar precisions with or without age, showing that age is probably not a factor
#determining. We notice that the model is particularly effective in finding non-survivors.

import pandas as pd

def predict_survival():
    
    print("Please enter the passenger's features :")
    
    pclass = int(input("Passenger class (1, 2, 3) : "))
    sex = int(input("Sex (1 for men, 0 for women) : "))
    sibsp = int(input("Number of siblings : "))
    parch = int(input("Parch : "))
    fare = float(input("Fare : "))
    embarked_s = int(input("Embarked in Southampton (1 for yes, 0 for no) : "))
    embarked_c = int(input("Embarked in Cherbourg (1 for yes, 0 for no) : "))
    embarked_q = int(input("Embarked in Queenstown (1 for yes, 0 for no) : "))

    # Create a dataframe with the input
    input_data = pd.DataFrame([[pclass, sex, sibsp, parch, fare, embarked_s, embarked_c, embarked_q]],
                              columns=['Pclass', 'Sex', 'SibSp', 'Parch', 'Fare', 'Embarked_S', 'Embarked_C', 'Embarked_Q'])
    
    # Ask if the age is available
    age_available = input("Is the age available ? (yes/no) : ").lower() == 'yes'
    
    if age_available:
        age = float(input("Age : "))
        input_data['Age'] = age
        prediction = final_model.predict(input_data)
    else:
        prediction = final_model2.predict(input_data)

    print("\nPrediction of survival : " + ("Survived" if prediction[0] == 1 else "Didn't survived"))
    
    print("\nInformation about the model:")
    print("This system uses two combined models to make predictions.")
    print("The model with age has an accuracy of X%, while the model without age has an accuracy of Y%.")
    print("Note that predictions may be less accurate for borderline or unrepresentative cases.")


predict_survival()


# In[22]:


# Confusion matrix with age

from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns

conf_matrix1 = confusion_matrix(y_test, final_y_pred)
sns.heatmap(conf_matrix1, annot=True, fmt='g')
plt.title('Confusion matrix of the model with age')
plt.xlabel('Predicted')
plt.ylabel('Real')
plt.show()


# In[23]:


# Confusion matrix without age

from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns

conf_matrix2 = confusion_matrix(y_test2, final_y_pred2)
sns.heatmap(conf_matrix2, annot=True, fmt='g')
plt.title('Confusion matrix of the model without age')
plt.xlabel('Predicted')
plt.ylabel('Real')
plt.show()


# In[24]:


# model with age

from sklearn.metrics import roc_curve, auc

fpr, tpr, thresholds = roc_curve(y_test, final_model.predict_proba(X_test)[:, 1])
roc_auc = auc(fpr, tpr)

plt.figure()
plt.plot(fpr, tpr, color='darkorange', lw=2, label='ROC curve (area = %0.2f)' % roc_auc)
plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Courbe ROC')
plt.legend(loc="lower right")
plt.show()


# In[25]:


# model without age

from sklearn.metrics import roc_curve, auc

fpr, tpr, thresholds = roc_curve(y_test2, final_model2.predict_proba(X_test2)[:, 1])
roc_auc = auc(fpr, tpr)

plt.figure()
plt.plot(fpr, tpr, color='darkorange', lw=2, label='ROC curve (area = %0.2f)' % roc_auc)
plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Courbe ROC')
plt.legend(loc="lower right")
plt.show()


# In[28]:


#export models

path1 = 'C:/Users/Gabriel/Desktop/Titanic notebook/model_1.pkl'
path2 = 'C:/Users/Gabriel/Desktop/Titanic notebook/model_2.pkl'

import pickle

with open(path1, 'wb') as fichier1:
    pickle.dump(final_model, fichier1)
with open(path2, 'wb') as fichier2:
    pickle.dump(final_model2, fichier2)


# In[ ]:




